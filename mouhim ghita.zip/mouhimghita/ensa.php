
<html>
<head><title>cadre1</title></head>
<body>
<p><h4 align="center">ECOLE NATIONALE DES SCIENCES APPLIQUES de F&egrave;s<br>
<img src="ensa.png" width="120px" height="50px"/>
</h4>
</p>
</body>
</html>
