<!doctype html>
<html>
<head>
<title> Acceuil </title > 
<link rel="stylesheet" type="text/css" href="miseEnPage.css">
</head>

<frameset rows="20%,80%">
<frame class="pagacc" src="ensa.php"name="cadre1">
<frameset cols="20%,80%">
<frame class="pagacc" src="menu.php"name="cadre2">
<frame src="bienvenue.php"name="cadre3">
</frameset>
</frameset>

</html>