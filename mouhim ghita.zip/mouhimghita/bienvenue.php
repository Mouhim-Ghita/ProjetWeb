<html>
<head>
<title>Acceuil du site</title> 
<link rel="stylesheet" type="text/css" href="miseEnPage.css">
</head>
<body class="bienvenue">
<h1>Bienvenue</h1>
</body>
</html>