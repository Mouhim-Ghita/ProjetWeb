<!doctype html>
<html>
<head>
<title>indices</title>
<link rel="stylesheet" href="miseEnPage.css">
</head>
<body border=2>
<p>
<h2>La gestion du mat&eacute;riel scientifique</h2>
</p>
<p class="sous_titre">G&eacute;rer mat&eacute;riel</p>
<p>
<ul class="list">
<li><a href="AjoutMateriel.php" target="cadre3"> Ajouter mat&eacute;riel</li></a>
<li><a href="ModifierMateriel.php" target="cadre3"> Modifier mat&eacute;riel</li></a>
<li><a href="supprimer.php" target="cadre3"> Supprimer mat&eacute;riel</li></a>
</ul>
</p>

<p class="sous_titre">rechercher mat&eacute;riel</p>
<p>
<ul class="list">
<li><a href="RechercherParDate.php" target="cadre3"> Rechercher par date</li></a>
<li><a href="RechercherParDesignation.php" target="cadre3"> Rechercher par d&eacute;signation</li></a>
<li><a href="RechercherParCategorie.php" target="cadre3">  Rechercher par cat&eacute;gorie</li></a>
</ul>
</p>

<p class="sous_titre">Affichage des statistiques</p>
<p>
<ul class="list">
<li><a href="AfficherParAnnee.php" target="cadre3"> Afficher couts par ann&eacute;e</li></a>
<li> <a href="AfficherParCat.php" target="cadre3">Afficher par cat&eacute;gorie</li></a>
</ul>
</p>

<a href="bienvenue.php" target="cadre3" class="acceuil">Retour &aacute; la page d'Acceuil</a>

</body>
</html>